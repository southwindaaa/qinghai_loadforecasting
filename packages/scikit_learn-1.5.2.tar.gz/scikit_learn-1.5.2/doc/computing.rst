============================
Computing with scikit-learn
============================

.. toctree::
    :maxdepth: 2

    computing/scaling_strategies
    computing/computational_performance
    computing/parallelism
