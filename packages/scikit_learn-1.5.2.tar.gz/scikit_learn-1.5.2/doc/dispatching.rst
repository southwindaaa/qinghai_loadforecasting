===========
Dispatching
===========

.. toctree::
    :maxdepth: 2

    modules/array_api
